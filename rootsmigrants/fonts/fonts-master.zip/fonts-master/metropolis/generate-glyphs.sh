#!/bin/bash

# Directory containing OTF files
FONT_DIR="./metropolis"

# Output directory for glyphs
OUTPUT_DIR="./glyphs"

# Create the output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Loop over each OTF file in the font directory
for font in "$FONT_DIR"/*.otf; do
    # Extract the base name of the font file (without extension)
    base_name=$(basename "$font" .otf)

    # Create a subdirectory for each font's glyphs
    font_output_dir="$OUTPUT_DIR/$base_name"
    mkdir -p "$font_output_dir"

    # Generate PBF glyphs for the font
    npx build-glyphs "$font" "$font_output_dir"

    echo "Generated glyphs for $font in $font_output_dir"
done
#!/bin/bash
# Directory containing OTF files
FONT_DIR="./metropolis"

# Output directory for glyphs
OUTPUT_DIR="./glyphs"

# Create the output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Loop over each OTF file in the font directory
for font in "$FONT_DIR"/*.otf; do
    # Extract the base name of the font file (without extension)
    base_name=$(basename "$font" .otf)

    # Create a subdirectory for each font's glyphs
    font_output_dir="$OUTPUT_DIR/$base_name"
    mkdir -p "$font_output_dir"

    # Generate PBF glyphs for the font
    npx build-glyphs "$font" "$font_output_dir"

    echo "Generated glyphs for $font in $font_output_dir"
done

