#!/bin/bash

# Directories containing font files (absolute paths)
METROPOLIS_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/metropolis"
ROBOTO_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/roboto"
NOTO_SANS_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/noto-sans"
OPEN_SANS_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/open-sans"
PT_SANS_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/pt-sans"

# Output directory for glyphs (absolute path)
OUTPUT_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/glyphs"

# Create the output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Function to generate glyphs
generate_glyphs() {
    local font_dir=$1
    local extension=$2

    for font in "$font_dir"/*."$extension"; do
        # Check if the font file exists
        if [[ -f "$font" ]]; then
            # Extract the base name of the font file (without extension)
            base_name=$(basename "$font" ".$extension")

            # Create a subdirectory for each font's glyphs
            font_output_dir="$OUTPUT_DIR/$base_name"
            mkdir -p "$font_output_dir"

            # Generate PBF glyphs for the font
            npx build-glyphs "$font" "$font_output_dir"

            echo "Generated glyphs for $font in $font_output_dir"
        else
            echo "No $extension files found in $font_dir"
        fi
    done
}

# Generate glyphs for OTF files in the metropolis directory
generate_glyphs "$METROPOLIS_DIR" "otf"

# Generate glyphs for TTF files in the other directories
generate_glyphs "$ROBOTO_DIR" "ttf"
generate_glyphs "$NOTO_SANS_DIR" "ttf"
generate_glyphs "$OPEN_SANS_DIR" "ttf"
generate_glyphs "$PT_SANS_DIR" "ttf"
#!/bin/bash

# Directory containing OTF files (absolute path)
FONT_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/metropolis"

# Output directory for glyphs (absolute path)
OUTPUT_DIR="/Users/lorettanwajiaku/Downloads/fonts-master/glyphs"

# Create the output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Loop over each OTF file in the font directory
for font in "$FONT_DIR"/*.otf; do
    # Extract the base name of the font file (without extension)
    base_name=$(basename "$font" .otf)

    # Create a subdirectory for each font's glyphs
    font_output_dir="$OUTPUT_DIR/$base_name"
    mkdir -p "$font_output_dir"

    # Generate PBF glyphs for the font
    npx build-glyphs "$font" "$font_output_dir"

    echo "Generated glyphs for $font in $font_output_dir"
done

